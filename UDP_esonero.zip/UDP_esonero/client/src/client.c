#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
    #include <winsock2.h>
    #define CLOSESOCKET closesocket
    typedef int socklen_t;
#else
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <unistd.h>
    #define CLOSESOCKET close
#endif

#include "protocol.h"

// Prints the help menu
void print_help_menu() {
    printf("\nPassword Generator Help Menu\n");
    printf("Commands:\n");
    printf(" h        : show this help menu\n");
    printf(" n LENGTH : generate numeric password (digits only)\n");
    printf(" a LENGTH : generate alphabetic password (lowercase letters)\n");
    printf(" m LENGTH : generate mixed password (lowercase letters and numbers)\n");
    printf(" s LENGTH : generate secure password (uppercase, lowercase, numbers, symbols)\n");
    printf(" u LENGTH : generate unambiguous secure password (no similar-looking characters)\n");
    printf(" q        : quit application\n");
    printf("\nLENGTH must be between %d and %d characters\n", MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
    fflush(stdout); // Ensure the menu is printed immediately
}

// Validates the user input
int validate_input(const char *input, char *command, int *length) {
    if (sscanf(input, "%c %d", command, length) == 2) {
        if (strchr("namus", *command) != NULL &&
            *length >= MIN_PASSWORD_LENGTH && *length <= MAX_PASSWORD_LENGTH) {
            return 1; // Valid command and length
        } else {
            printf("Error: Length must be between %d and %d characters.\n",
                   MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
            fflush(stdout); // Ensure error is printed immediately
        }
    } else if (strcmp(input, "h") == 0 || strcmp(input, "q") == 0) {
        *command = input[0];
        return 1; // Valid help or quit command
    }
    printf("Error: Invalid command. Type 'h' for help.\n");
    fflush(stdout); // Ensure error is printed immediately
    return 0; // Invalid input
}

int main() {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        fprintf(stderr, "Failed to initialize Winsock. Error Code: %d\n", WSAGetLastError());
        exit(EXIT_FAILURE);
    }
#endif

    struct sockaddr_in server_addr;
    struct hostent *host;
    char buffer[1024];
    char response[1024];
    char command;
    int length;
    int sockfd;

    // Resolve the hostname using gethostbyname
    host = gethostbyname("passwdgen.uniba.it");
    if (host == NULL) {
        fprintf(stderr, "Failed to resolve hostname.\n");
        fflush(stderr); // Ensure error is printed immediately
#ifdef _WIN32
        WSACleanup();
#endif
        exit(EXIT_FAILURE);
    }

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
#ifdef _WIN32
        WSACleanup();
#endif
        exit(EXIT_FAILURE);
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(12345);
    memcpy(&server_addr.sin_addr, host->h_addr, host->h_length);

    // Main loop for user interaction
    while (1) {
        printf("\nEnter command (type 'h' for help): ");
        fflush(stdout); // Ensure prompt is printed immediately
        fgets(buffer, sizeof(buffer), stdin);

        // Remove trailing newline character
        buffer[strcspn(buffer, "\n")] = '\0';

        // Validate input
        if (!validate_input(buffer, &command, &length)) {
            continue; // Prompt the user again if input is invalid
        }

        // Handle quit command
        if (command == CMD_QUIT) {
            printf("Exiting...\n");
            fflush(stdout); // Ensure exit message is printed immediately
            break;
        }

        // Handle help command
        if (command == CMD_HELP) {
            print_help_menu();
            continue;
        }

        // Send command to server
        printf("Sending command: %s\n", buffer);
        fflush(stdout); // Ensure sending message is printed immediately
        if (sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
            perror("Failed to send data");
            continue;
        }

        // Receive response from server
        memset(response, 0, sizeof(response));
        if (recvfrom(sockfd, response, sizeof(response), 0, NULL, NULL) < 0) {
            perror("Failed to receive data");
            continue;
        }

        // Print the generated password
        printf("Generated Password: %s\n", response);
        fflush(stdout); // Ensure password is printed immediately
    }

    // Close the socket and clean up
    CLOSESOCKET(sockfd);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
