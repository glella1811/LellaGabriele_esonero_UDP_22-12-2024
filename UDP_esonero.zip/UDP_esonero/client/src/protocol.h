#ifndef PROTOCOL_H
#define PROTOCOL_H

// Maximum and minimum password length
#define MIN_PASSWORD_LENGTH 6
#define MAX_PASSWORD_LENGTH 32

// Commands
#define CMD_NUMERIC 'n'
#define CMD_ALPHA 'a'
#define CMD_MIXED 'm'
#define CMD_SECURE 's'
#define CMD_UNAMBIGUOUS 'u'
#define CMD_HELP 'h'
#define CMD_QUIT 'q'

#endif // PROTOCOL_H
