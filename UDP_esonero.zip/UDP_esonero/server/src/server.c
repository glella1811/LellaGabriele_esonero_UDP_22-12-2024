#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
    #include <winsock2.h>
    #define CLOSESOCKET closesocket
    typedef int socklen_t;
#else
    #include <arpa/inet.h>
    #include <unistd.h>
    #define CLOSESOCKET close
#endif

#include "protocol.h"

// Password generation functions
void generate_numeric(char *password, int length);
void generate_alpha(char *password, int length);
void generate_mixed(char *password, int length);
void generate_secure(char *password, int length);
void generate_unambiguous(char *password, int length);

void generate_password(char command, int length, char *password) {
    switch (command) {
        case CMD_NUMERIC:
            generate_numeric(password, length);
            break;
        case CMD_ALPHA:
            generate_alpha(password, length);
            break;
        case CMD_MIXED:
            generate_mixed(password, length);
            break;
        case CMD_SECURE:
            generate_secure(password, length);
            break;
        case CMD_UNAMBIGUOUS:
            generate_unambiguous(password, length);
            break;
        default:
            strcpy(password, "INVALID_COMMAND");
    }
}

void handle_request(int sockfd, struct sockaddr_in *client_addr, socklen_t client_len, char *buffer) {
    char command;
    int length;
    char response[MAX_PASSWORD_LENGTH + 1] = {0};

    // Parse client request
    if (sscanf(buffer, "%c %d", &command, &length) != 2 || length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
        strcpy(response, "ERROR_INVALID_REQUEST");
    } else {
        generate_password(command, length, response);
    }

    // Log the request
    printf("New request from %s:%d\n", inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port));
    printf("Received data: %s\n", buffer);
    printf("Generated Password: %s\n", response);
    fflush(stdout);

    // Send response back to client
    sendto(sockfd, response, strlen(response), 0, (struct sockaddr *)client_addr, client_len);
}

int main() {
#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        fprintf(stderr, "Failed to initialize Winsock. Error Code: %d\n", WSAGetLastError());
        exit(EXIT_FAILURE);
    }
#endif

    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    char buffer[1024];
    int sockfd;

    // Initialize random seed
    srand((unsigned int)time(NULL));

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
#ifdef _WIN32
        WSACleanup();
#endif
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(12345);

    // Bind socket
    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        CLOSESOCKET(sockfd);
#ifdef _WIN32
        WSACleanup();
#endif
        exit(EXIT_FAILURE);
    }

    printf("Server is running on port 12345...\n");
    fflush(stdout);

    // Main loop
    while (1) {
        memset(buffer, 0, sizeof(buffer));
        recvfrom(sockfd, buffer, sizeof(buffer), 0, (struct sockaddr *)&client_addr, &client_len);
        handle_request(sockfd, &client_addr, client_len, buffer);
    }

    CLOSESOCKET(sockfd);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}

void generate_numeric(char *password, int length) {
    for (int i = 0; i < length; i++) {
        password[i] = '0' + (rand() % 10);
    }
    password[length] = '\0';
}

void generate_alpha(char *password, int length) {
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + (rand() % 26);
    }
    password[length] = '\0';
}

void generate_mixed(char *password, int length) {
    for (int i = 0; i < length; i++) {
        if (rand() % 2) {
            password[i] = 'a' + (rand() % 26);
        } else {
            password[i] = '0' + (rand() % 10);
        }
    }
    password[length] = '\0';
}

void generate_secure(char *password, int length) {
    const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    int charset_size = strlen(charset);
    for (int i = 0; i < length; i++) {
        password[i] = charset[rand() % charset_size];
    }
    password[length] = '\0';
}

void generate_unambiguous(char *password, int length) {
    const char charset[] = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz234679";
    int charset_size = strlen(charset);
    for (int i = 0; i < length; i++) {
        password[i] = charset[rand() % charset_size];
    }
    password[length] = '\0';
}
